prompt = 'enter the number : '
x = input(prompt);
        if x>0
            fprintf('the number is positive')
        else if x<0
            fprintf('the number is negative')
        else
            fprintf('the number is zero')
        end
        end
