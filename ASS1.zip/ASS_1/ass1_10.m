a = [2 7 6; 9 5 1; 4 3 8]
sum1=0;sum2=0;sum3=0;row=0;
    for j=1:3
        sum1=sum1+a(1,j)
    end
    for j=1:3
        sum2=sum2+a(2,j)
    end
	for j=1:3
        sum3=sum3+a(3,j)
	end
    if sum1 == sum2 && sum2 == sum3 
        row=sum1;
	else
		fprintf('not magic square');
    end
    
sum4=0;sum5=0;sum6=0;column=0;
    for i=1:3
        sum4=sum4+a(i,1)
    end
    for i=1:3
        sum5=sum5+a(i,2)
    end
	for i=1:3
        sum6=sum6+a(i,3)
		end
    if sum4 == sum5 && sum5 == sum6 
	column=sum4
	else
		fprintf('not magic square');
    end

sum=0;
    for j=1:3
        sum=sum+a(j,j)
    end
    
    if row == column && row == sum
	fprintf('matrix is magic square');
	else
		fprintf('not magic square');
    end

