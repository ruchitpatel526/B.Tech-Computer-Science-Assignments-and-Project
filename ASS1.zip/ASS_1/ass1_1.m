a = [1 2 3; 4 5 6; 7 8 10]
for i=1:3
    for j=1:3
        if(isprime(a(i,j)))
            sprintf('at index [%d:%d] the numbere %d is prime ',i,j,a(i,j))
        end
    end
end