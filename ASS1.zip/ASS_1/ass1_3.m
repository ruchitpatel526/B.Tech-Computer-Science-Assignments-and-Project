prompt = 'enter number = '
x = input(prompt);
rnum=0;
while(x>0)
    m= mod(x,10);
    rnum = rnum * 10 + m;
    x = (x-m) /10;
end
    fprintf('reverse num is %d',rnum)
       