a = [1 2 3; 4 5 6; 7 8 10]
for i=1:3
    for j=1:3
        if mod(a(i,j),5)==0 || mod(a(i,j),7)==0
		   sprintf('at index [%d:%d] the number is divisible by 5 or 7',i,j)
        end
    end
end
