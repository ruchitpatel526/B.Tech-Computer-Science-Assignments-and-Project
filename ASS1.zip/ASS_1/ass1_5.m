prompt = 'enter number = '
x = input(prompt);
largest=0;
while(x>0)
    digit = mod(x,10);
	if digit>largest
	largest=digit
   
    x = (x-digit) /10;
    end
end
    fprintf('largest number is %d ',largest)
	
	