 prompt = 'enter number = '
x = input(prompt);
sum=mod(x,10);
while(x>0)
   m= mod(x,10);
    x = (x-m) /10;
end
	sum = sum+m
    fprintf(' %d ',sum)
	