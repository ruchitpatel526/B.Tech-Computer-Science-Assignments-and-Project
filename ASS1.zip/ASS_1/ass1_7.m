prompt = 'enter first number = '
x = input(prompt);
prompt = 'enter second number = '
y = input(prompt);
prompt = 'enter number f terms = '
terms = input(prompt);
fprintf('%d %d ',x,y)

for i=3:terms
	z=x+y;
	fprintf('%d ',z)
	x=y;
	y=z;
	end
	
