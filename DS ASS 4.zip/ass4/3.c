#include <stdio.h>
#include <stdlib.h>
struct node{
	int roll_no;
	int cgpa;
	char name[20];
	struct node* link;
};
struct node* head=NULL;
struct node* value(){
	struct node *temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter roll no. : ");
	scanf("%d",&temp->roll_no);
	printf("Enter Name : ");
	scanf(" %[^\n\t]s",temp->name);
	printf("\nEnter CGPA : ");
	scanf("%d",&temp->cgpa);
	temp->link=head;
	return temp;
}
int size(){
	struct node *trav;
	int count=0;
	trav=head;
	if(head==NULL)
	{
		return count;
	}
	do
	{
		trav=trav->link;
		count++;
	}while(trav!=head);
	return count;
}
void display(){
	struct node *trav;
	trav=head;
	if(head==NULL)
	{
		printf("\nNo data");
	}
	do
	{
		printf("\nRoll no. : %d",trav->roll_no);
		printf("\nName : %s",trav->name);
		printf("\nCGPA : %d\n",trav->cgpa);
		trav=trav->link;
	}while(trav!=head);
}
void insertEnd(){
	struct node *temp,*trav,*prev;
	temp = value();
	trav=head;
	if(head==NULL)
		head=temp;
	else
	{
		do
		{
			prev=trav;
			trav=trav->link;
		}while(trav!=head);
		prev->link=temp;
	}
}
void insertHead(){
	struct node *temp,*trav,*prev;
	temp = value();
	trav=head;
	if(head==NULL)
		head=temp;
	else
	{
		do
		{
			prev=trav;
			trav=trav->link;
		}while(trav!=head);
		prev->link=temp;
	}
	head=temp;
}
void insertBet(int ind){
	struct node *trav,*temp,*prev;int i=0;
	if(ind==0)
	{
		insertHead();
		return;
	}
	if(ind>=size())
	{
		insertEnd();
		return;
	}
	temp = value();
	trav=head;
	if(ind!=0)
	{
		for(i=0;i<ind;i++)
		{
			prev=trav;
			trav=trav->link;
		}
		prev->link=temp;
		temp->link=trav;
	}
}
void del(int del){
	struct node *trav,*temp,*prev;
	if(head==NULL)
	{
		printf("No data to be deleted");
		return;
	}
	prev=head;
	trav=head->link;
	while(trav!=head->link)
	{
		if(trav->roll_no==del)
		{
			prev->link=trav->link;
			if(trav==head)
			{
				head=trav->link;
			}
			free(trav);
			trav=NULL;
			return;
		}
		prev=trav;
		trav=trav->link;
	}
	printf("\nNo data found");
}
void search(int ser){
	struct node *trav;
	int count=0;
	trav=head;
	if(head==NULL)
	{
		printf("\nNot Found");
		return;
	}
	do
	{
		if(trav->roll_no==ser)
		{
			printf("\nFound at %d",count+1);
			return;
		}
		trav=trav->link;
		count++;
	}while(trav!=head);
	printf("\nNot Found");
}
void main(){
	int num=0,ind=0,delNum=0,ser=0;
	head=NULL;
	while(1)
	{
		int choice=0;
		printf("\n1 : Insert at End");
		printf("\n2 : Insert at Start");
		printf("\n3 : Insert at Between");
		printf("\n4 : Delete");
		printf("\n5 : Search");
		printf("\n6 : Display");
		printf("\n7 : Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insertEnd();
				break;
			case 2:
				insertHead();
				break;
			case 3:
				printf("Enter index number to insert = ");
				scanf("%d",&ind);
				insertBet(ind);
				break;
			case 4:
				printf("\nEnter Roll Number to delete = ");
				scanf("%d",&delNum);
				del(delNum);
				break;
			case 5:
				printf("\nEnter Roll Number to search = ");
				scanf("%d",&ser);
				search(ser);
				break;
			case 6:
				display();
				break;
			case 7:
				exit(0);
				break;
			default:
				printf("\nWrong Choice");
		}
	}
}
