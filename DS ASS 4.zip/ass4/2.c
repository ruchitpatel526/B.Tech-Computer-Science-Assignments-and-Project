#include <stdio.h>
#include <stdlib.h>
struct node{
	int roll_no;
	int cgpa;
	char name[20];
	struct node* link;
};
struct node* head;
void insert()
{
	struct node* temp;
	struct node *trav,*pre;
	temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter roll no. : ");
	scanf("%d",&temp->roll_no);
	printf("Enter Name : ");
	scanf(" %[^\n\t]s",temp->name);
	printf("\nEnter CGPA : ");
	scanf("%d",&temp->cgpa);
	temp->link=NULL;
	if(head==NULL)
	{
		head=temp;
		return;
	}
	else
	{
		trav=head;
		while(trav!=NULL)
		{
			if(trav->roll_no >= temp->roll_no)
			{
				if(trav==head)
				{
					temp->link=head;
					head=temp;
					return;
				}
				else
				{
					temp->link = trav;
					pre->link = temp;
					return;
				}
			}
			pre=trav;
			trav=trav->link;
		}
		pre->link=temp;
		return;
	}
}
void display(){
	struct node *trav;
	trav=head;
	if(head==NULL)
	{
		printf("\nNo data");
	}
	while(trav!=NULL)
	{
		printf("\nRoll no. : %d",trav->roll_no);
		printf("\nName : %s",trav->name);
		printf("\nCGPA : %d\n",trav->cgpa);
		trav=trav->link;
	}
}
void search(int ser){
	struct node *trav;
	int count=0;
	trav=head;
	while(trav!=NULL){
		if(trav->roll_no==ser)
		{
			printf("\nFound at %d",count+1);
			return;
		}
		trav=trav->link;
		count++;
	}
	printf("\nNot Found");
}
void del(int del){
	struct node *trav,*temp,*prev;
	if(head==NULL){
		printf("No data to be deleted");
		return;
	}
	if(head->roll_no==del)
	{
		temp=head;
		head=head->link;
		free(temp);
		return;
	}
	else
	{
		prev=head;
		trav=head;
		while(trav!=NULL)
		{
			if(trav->roll_no==del)
			{
				prev->link=trav->link;
				free(trav);
				return;
			}
			prev=trav;
			trav=trav->link;
		}
	}
	printf("\nNo data found");
}
void main()
{
	int num=0,delNum=0,ser=0;
	head=NULL;
	while(1)
	{
		int choice=0;
		printf("\n1 : Insert");
		printf("\n2 : Delete");
		printf("\n3 : Search");
		printf("\n4 : Display");
		printf("\n5 : Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insert();
				break;
			case 2:
				printf("\nEnter Roll Number to delete = ");
				scanf("%d",&delNum);
				del(delNum);
				break;
			case 3:
				printf("\nEnter Roll Number to search = ");
				scanf("%d",&ser);
				search(ser);
				break;
			case 4:
				display();
				break;
			case 5:
				exit(0);
				break;
			default:
				printf("\nWrong Choice");
		}
	}

	
}
