#include <stdio.h>
#include <stdlib.h>
struct node{
	int roll_no;
	int cgpa;
	char name[20];
	struct node* prev;
	struct node* next;
};
struct node* head=NULL;
struct node* value(){
	struct node *temp = (struct node*)malloc(sizeof(struct node));
	printf("\nEnter roll no. : ");
	scanf("%d",&temp->roll_no);
	printf("Enter Name : ");
	scanf(" %[^\n\t]s",temp->name);
	printf("\nEnter CGPA : ");
	scanf("%d",&temp->cgpa);
	temp->prev=NULL;
	temp->next=NULL;
	return temp;
}
int size(){
	struct node *trav;
	int count=0;
	trav=head;
	while(trav!=NULL)
	{
		trav=trav->next;
		count++;
	}
	return count;
}
void display(){
	struct node *trav;
	trav=head;
	if(head==NULL)
	{
		printf("\nNo data");
	}
	while(trav!=NULL)
	{
		printf("\nRoll no. : %d",trav->roll_no);
		printf("\nName : %s",trav->name);
		printf("\nCGPA : %d\n",trav->cgpa);
		trav=trav->next;
	}
}
void insertEnd(){
	struct node *temp,*trav;
	trav=head;
	temp = value();
	if(head==NULL)
		head=temp;
	else
	{
		while(trav->next!=NULL)
		{
			trav=trav->next;
		}
		trav->next=temp;
		temp->prev=trav;
	}
}
void insertHead(){
	struct node* temp;
	temp = value();
	temp->next=head;
	head=temp;
}
void insertBet(int ind)
{
	struct node *trav,*temp;int i=0;
	trav=head;
	if(ind==0)
	{
		insertHead();
		return;
	}
	if(ind>=size())
	{
		insertEnd();
		return;
	}
	else
	{
		temp = value();
		for(i=0;i<ind && trav!=NULL;i++)
		{
			trav=trav->next;
		}
		trav->prev->next=temp;
		temp->next=trav;
		trav->next->prev=temp;
	}
}
void del(int del){
	struct node *trav,*temp;
	if(head==NULL){
		printf("No data to be deleted");
		return;
	}
	if(head->roll_no==del)
	{
		head=head->next;
		head->prev=NULL;
		return;
	}
	else
	{
		trav=head;
		while(trav!=NULL)
		{
			if(trav->roll_no==del)
			{
				trav->prev->next=trav->next;
				if(trav->next!=NULL)
				{
				trav->next->prev=trav->prev;
				}
				free(trav);
				trav=NULL;
				return;
			}
			trav=trav->next;
		}
	}
	printf("\nNo data found");
}
void search(int ser){
	struct node *trav;
	int count=0;
	trav=head;
	while(trav!=NULL){
		if(trav->roll_no==ser)
		{
			printf("\nFound at %d",count+1);
			return;
		}
		trav=trav->next;
		count++;
	}
	printf("\nNot Found");
}
int main()
{
	int num=0,ind=0,delNum=0,ser=0;
	head=NULL;
	while(1)
	{
		int choice=0;
		printf("\n1 : Insert at End");
		printf("\n2 : Insert at Start");
		printf("\n3 : Insert at Between");
		printf("\n4 : Delete");
		printf("\n5 : Search");
		printf("\n6 : Display");
		printf("\n7 : Exit");
		printf("\nEnter your choice : ");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				insertEnd();
				break;
			case 2:
				insertHead();
				break;
			case 3:
				printf("\nEnter index number to insert = ");
				scanf("%d",&ind);
				insertBet(ind);
				break;
			case 4:
				printf("\nEnter Roll Number to delete = ");
				scanf("%d",&delNum);
				del(delNum);
				break;
			case 5:
				printf("\nEnter Roll Number to search = ");
				scanf("%d",&ser);
				search(ser);
				break;
			case 6:
				display();
				break;
			case 7:
				exit(0);
				break;
			default:
				printf("\nWrong Choice");
		}
	}
	return 0;
}

