#include <stdio.h>
#include <stdlib.h>
int num=0,i=0;
int a[100];int inum;int ind;
void show()
{
	for(i=0;i<num;i++)
	{
		printf("\na[%d] = %d",i,a[i]);
	}
}
void del()
{
	printf("\nEnter index num to delete = ");
	scanf("%d",&ind);
	for(i=ind;i<num-1;i++)
	{
		a[i]= a[i+1];
	}
	num--;
}
int main()
{
	printf("\nEnter number of element to insert = ");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		printf("\na[%d] = ",i);
		scanf("%d",&a[i]);
	}
	del();
	show();
	return 0;
}

