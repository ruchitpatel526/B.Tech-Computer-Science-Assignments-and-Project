#include <stdio.h>
#include <stdlib.h>
int min=0,max=0;int num=0,i,a[100];
int maximum()
{
	max = a[0];
	for(i=0;i<num;i++)
	{
		max = (a[i] > max)?a[i]:max;
	}	
	return max;
}
int minimum()
{
	min = a[0];
	for(i=0;i<num;i++)
	{
		min = (a[i] < min)?a[i]:min;
	}
	return min;
}
void main()
{
	
	
	printf("\nEnter number of person(age) to insert = ");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		printf("\na[%d] = ",i);
		scanf("%d",&a[i]);
	}
	

	printf("\nmin = %d",minimum());
	printf("\nmax = %d",maximum());
}
