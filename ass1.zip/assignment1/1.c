#include <stdio.h>
#include <stdlib.h>
void main()
{
	int sumation=0;int number=0,i,a[100];
	float avg=0;
	printf("\nEnter numberber of element to insert = ");
	scanf("%d",&number);
	for(i=0;i<number;i++)
	{
		printf("\na[%d] = ",i);
		scanf("%d",&a[i]);
		sumation+=a[i];
		
	}
	avg=(float)sumation/number;
	printf("\nsumation = %d",sumation);
	printf("\navg = %f",avg);
}
