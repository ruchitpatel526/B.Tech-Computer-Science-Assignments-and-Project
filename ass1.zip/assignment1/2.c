#include <stdio.h>
#include <stdlib.h>
void main()
{
	int minimum=0,maximum=0;int num=0,i,a[100];
	
	printf("\nEnter number of person(age) to insert = ");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		printf("\na[%d] = ",i);
		scanf("%d",&a[i]);
	}
	minimum = a[0];maximum = a[0];
	for(i=0;i<num;i++)
	{
		maximum = (a[i] > maximum)?a[i]:maximum;
		minimum = (a[i] < minimum)?a[i]:minimum;
	}
	printf("\nminimum = %d",minimum);
	printf("\nmaximum = %d",maximum);
}
