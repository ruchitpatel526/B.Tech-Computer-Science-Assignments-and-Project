#include <stdio.h>
#include <stdlib.h>
int num=0,i=0;
int a[100];int inum;int ind;
void show()
{
	for(i=0;i<num;i++)
	{
		printf("\na[%d] = %d",i,a[i]);
	}
}
void insert()
{
	printf("\nEnter Element to insert = ");
	scanf("%d",&inum);
	printf("\nEnter into index = ");
	scanf("%d",&ind);
	for(i=num;i>ind;i--)	
	{
		a[i] = a[i-1];
	}
	a[ind] = inum;
	num++;
}
int main()
{
	printf("\nEnter number of element to insert = ");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		printf("\na[%d] = ",i);
		scanf("%d",&a[i]);
	}
	insert();
	show();
	return 0;
}

