#include <stdio.h>
struct weight{
	int kilo;
	int gram;	
};
void main()
{
	struct weight w1,w2,w3;
	printf("\nEnter first person weight(kilo gram) =  ");
	scanf("%d %d",&w1.kilo,&w1.gram);
	printf("\nEnter first person weight(kilo gram) =  ");
	scanf("%d %d",&w2.kilo,&w2.gram);
	w3.	kilo = w1.kilo + w2.kilo + ((w1.gram+w2.gram)/1000);
	w3.gram = (w1.gram + w2.gram)%1000;
	printf("\nAfter Adding wieght = %d kilo %d gram",w3.kilo,w3.gram);
}
