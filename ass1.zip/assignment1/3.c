#include <stdio.h>
#include <stdlib.h>
void main()
{
	int min=0,max=0;int num=0,i,a[100],b[100],count=0;
	
	printf("\nEnter number of person(age) to insert = ");
	scanf("%d",&num);
	for(i=0;i<num;i++)
	{
		printf("\na[%d] = ",i);
		scanf("%d",&a[i]);
	}
	min = a[0];max = a[0];
	for(i=0;i<num;i++)
	{
		max = (a[i] > max)?a[i]:max;
		min = (a[i] < min)?a[i]:min;
	}
	for(i=0;i<num;i++)
	{
		if(a[i]==min || a[i]==max)
		{
			continue;
		}
		else
		{
			b[count]=a[i];
			count++;
		}
	}
	min = b[0];max = b[0];
	for(i=0;i<count;i++)
	{
		max = (b[i] > max)?b[i]:max;
		min = (b[i] < min)?b[i]:min;
	}
	printf("\nsecond min = %d",min);
	printf("\nsecond max = %d",max);
}
