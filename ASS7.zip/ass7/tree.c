#include <stdio.h>
#include <stdlib.h>
#define MAX 65344

struct node{
	int data;
	struct node* lptr;
	struct node* rptr;
};
struct node *head;

int search(){
	int val;
	struct node* trav;
	printf("\nEnter data to be search :: ");
	scanf("%d",&val);
	if(head->lptr == NULL && head->rptr == NULL)
	{
		printf("\nNo Data for search.");
		return 0;
	}
	trav=head->lptr;
	while(trav!=NULL)
	{
		if(val < trav->data)
		{
			if(trav->lptr == NULL)
			{
				return 0;
			}
			trav = trav->lptr;
		}
		if(val > trav->data)
		{
			if(trav->rptr == NULL)
			{
				return 0;
			}
			trav = trav->rptr;
		}
		if(val == trav->data)
		{
			return 1;
		}
	}
	return 0;
	
}
struct node* findRoot(int val){
	struct node* trav;
	if(head->lptr == NULL && head->rptr == NULL)
	{
		return head;
	}
	trav=head->lptr;
	while(trav!=NULL)
	{
		if(val < trav->data)
		{
			if(trav->lptr == NULL)
			{
				return trav;
			}
			trav = trav->lptr;
		}
		if(val > trav->data)
		{
			if(trav->rptr == NULL)
			{
				return trav;
			}
			trav = trav->rptr;
		}
		if(val == trav->data)
		{
			return NULL;
		}
	}
	return NULL;
}
struct node* create()
{
	struct node *temp;
	temp = (struct node*)malloc(sizeof(struct node));
	printf("Enter Data to be inserted :: ");
	scanf("%d",&temp->data);
	temp->lptr = NULL;
	temp->rptr = NULL;
	return temp;
}
void insert(){
	struct node *temp,*parent;
	temp = create();
	parent = findRoot(temp->data);
	if(parent == NULL)
	{
		printf("Value Exists");
		return;
	}
	if(temp->data < parent->data)
	{
		parent->lptr = temp;
	}
	else
	{
		parent->rptr = temp;
	}
}
void inOrder(struct node* root)
{
	if(root==NULL)
		return;
	if(root->lptr!=NULL)
	{
		inOrder(root->lptr);
	}
	printf("\t %d",root->data);
	if(root->rptr!=NULL)
	{
		inOrder(root->rptr);
	}
}
void preOrder(struct node* root)
{
	if(root==NULL)
		return;
	printf("\t%d",root->data);
	if(root->lptr!=NULL)
	{
		inOrder(root->lptr);
	}
	if(root->rptr!=NULL)
	{
		inOrder(root->rptr);
	}
}
void postOrder(struct node* root)
{
	if(root==NULL)
		return;
	if(root->lptr!=NULL)
	{
		inOrder(root->lptr);
	}
	if(root->rptr!=NULL)
	{
		inOrder(root->rptr);
	}
	printf("\t%d",root->data);
}
void main()
{
	int ch=0,num=0,i=0;
	head = (struct node*)malloc(sizeof(struct node));
	head->data = MAX;
	head->lptr = NULL;
	head->rptr = NULL;
	while(1){
		printf("\n1 :: Create Tree");
		printf("\n2 :: Search");
		printf("\n3 :: Inorder Traversal");
		printf("\n4 :: Preorder Traversal");
		printf("\n5 :: Postorder Traversal");
		printf("\n6 :: Exit");
		printf("\nEnter choice :: ");
		scanf("%d",&ch);
		
		switch(ch)
		{
			case 1:
				printf("How many nodes :: ");
				scanf("%d",&num);
				for(i=0;i<num;i++)
				{
					insert();
				}
				break;
			case 2:
				printf("%d",search());
				break;
			case 3:
				printf("\nInOrder Traversal");
				inOrder(head->lptr);
				break;
			case 4:
				printf("\nPreOrder Traversal");
				preOrder(head->lptr);
				break;
			case 5:
				printf("\nPostOrder Traversal");
				postOrder(head->lptr);
				break;
			case 6:
				exit(0);
				break;
			default:
				printf("\nWrong Choice");
		}
	}
}
