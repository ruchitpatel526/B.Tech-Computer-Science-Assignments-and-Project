<!DOCTYPE html>
<html>
<head>
	<title>vowel</title>
</head>
<body>
	<?php
		$c = $_GET["char"];
		switch($c)
		{
			case "A":
			case "a": echo "The Character $c is a Vowel";
						break;
			case "E":
			case "e": echo "The Character $c is a Vowel";
						break;
			case "I":
			case "i": echo "The Character $c is a Vowel";
						break;
			case "O":
			case "o": echo "The Character $c is a Vowel";
						break;
			case "U":
			case "u": echo "The Character $c is a Vowel";
						break;
			default: echo "The character is a consonant";
		}
	?>
</body>
</html>