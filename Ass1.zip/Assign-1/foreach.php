<!DOCTYPE html>
<html>
<head>
	<title>Foreach</title>
</head>
<body>
	<?php
		$arr=array("one","two","three");
		foreach($arr as $value)
			echo "$value<br>";
	?>
</body>
</html>