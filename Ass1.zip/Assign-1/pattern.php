<!DOCTYPE html>
<html>
<head>
	<title>Pattern</title>
</head>
<body>
		<?php
			$rows=$_GET["rows"];
			for($i=0;$i<$rows;$i++)
			{
				for($j=$rows-$i;$j>0;$j--)
					echo "*";
				echo "<br>";
			}
		?>
</body>
</html>