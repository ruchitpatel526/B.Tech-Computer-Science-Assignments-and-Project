<!DOCTYPE html>
<html>
<head>
	<title>Function</title>
</head>
<body>
		<?php
			function writeName($n)
			{
				echo "my name is $n";
			} 
			$name=$_GET["name"];
			writeName($name);
		?>
</body>
</html>