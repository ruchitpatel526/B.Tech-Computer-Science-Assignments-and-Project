<!DOCTYPE html>
<html>
<head>
	<title>Matrix</title>
</head>
<body>
		<?php
			$m1= array(array(2,2),array(3,4));
			$m2= array(array(3,2),array(6,3));
			echo "Matrix-1<br>";
			for($i=0;$i<2;$i++)
			{
				for($j=0;$j<2;$j++)
					echo $m1[$i][$j]." ";
				echo "<br>";
			}
			echo "Matrix-2<br>";
			for($i=0;$i<2;$i++)
			{
				for($j=0;$j<2;$j++)
					echo $m2[$i][$j]." ";
				echo "<br>";
			}
			echo "Added Matrix<br>";
			for($i=0;$i<2;$i++)
			{
				for($j=0;$j<2;$j++)
					echo $m1[$i][$j]+$m2[$i][$j]." ";
				echo "<br>";
			}
		?>
</body>
</html>