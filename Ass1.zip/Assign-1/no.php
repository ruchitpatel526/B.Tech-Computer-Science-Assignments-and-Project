<!DOCTYPE html>
<html>
<head>
	<title>No</title>
</head>
<body>
		<?php
				$n1=$_GET["no1"];
				$n2=$_GET["no2"];
				echo "Addition of $n1 and $n2 is ",$n1+$n2,"<br>";
				echo "Subtraction of $n1 and $n2 is ",$n1-$n2,"<br>";
				echo "Multiplication of $n1 and $n2 is ",$n1*$n2,"<br>";
				echo "Division of $n1 and $n2 is ",$n1/$n2,"<br>";
				echo "\n\n\n";
				if($n1>$n2)
					echo "$n1 is greater than $n2";
				else if($n1<$n2)
					echo "$n2 is greater than $ n1";
				else
					echo "both are equal";
		?>
</body>
</html>