<!DOCTYPE html>
<html>
<head>
	<title>EvenOdd</title>
</head>
<body>
		<?php
				$v=$_GET["no"];
				if($v%2==0)
					echo "The Number $v is a even number<br>";
				else
					echo "The Number $v is an odd number<br>";
		?>
</body>
</html>