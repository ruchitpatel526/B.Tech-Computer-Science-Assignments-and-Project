<!DOCTYPE html>
<html>
<head>
	<title>Week</title>
</head>
<body>
		<?php
			$week = array("sunday","monday","tuesday","Wednesday","Thursday","Friday","saturday");
			for($i=0;$i<7;$i++)
				echo $week[$i],"<br>";
		?>
</body>
</html>