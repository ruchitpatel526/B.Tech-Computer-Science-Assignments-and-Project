<!DOCTYPE html>
<html>
<head>
	<title>Function</title>
</head>
<body>
		<?php
			function writeName($n,$s)
			{
				return $n." ".$s;
			}
			$sname=$_GET["sname"];
			$name=$_GET["name"];
			$fname=$_GET["fname"];
			echo "my name is ".writeName($name,$sname)." <br>";
			echo "my Father's name is ".writeName($fname,$sname)." <br>";
		?>
</body>
</html>