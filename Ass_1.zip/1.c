#include<stdio.h>
#include<math.h>
int main()

{
   int num,reminder,i=0,deci_num=0;
    printf("enter num = ");
scanf("%d",&num);
while(num!=0)ss
{
reminder=num%10;
  deci_num+=pow(2,i)*(reminder);
  num=num/10;
  i++;
}
printf("value =  %d",deci_num);
}
  
