#include<stdio.h>
#include<math.h>
int main()

{
   int num,i=0,bin_num=0;
   printf("number = ");
    scanf("%d",&num);
   while(num!=1)
{
  bin_num+=pow(10,i)*(num%2);
  num=num/2;
  i++;
}
bin_num+=pow(10,i)*(num%2);
printf("binary value = %d",bin_num);
}
  
