#include <stdio.h>
#include <math.h>
int mul=1;
int fact(int num)
{
	if(num==1)
		return 1;
	else
	{
		mul=num*fact(num-1);
		return mul;
		
	}
}
void main()
{
	int num;
	printf("Enter number = ");
	scanf("%d",&num);
	printf("%d",fact(num));
}

