#include<stdio.h>
#include<stdlib.h>
 struct book {
	char book_name[20];
	int book_id,book_price;
};
struct stack {
   struct book s[5];
   int top;
} st;
 


int stfull() {
   if (st.top >= 4)
      return 1;
   else
      return 0;
}
 
void push() {
	if(stfull())
	printf("stack is full");
	else
	{
	st.top++;
	printf("\nEnter bookname ,bookid and bookprice :: \n");
      scanf("%s %d %d",st.s[st.top].book_name,&st.s[st.top].book_id,&st.s[st.top].book_price);  
       }
}

int stempty() {
	if(st.top == -1)
	return 1;
	else
	return 0;

}
void peep() {
	printf("\n%s %d %d",st.s[st.top].book_name,st.s[st.top].book_id,st.s[st.top].book_price);  
       
}


void pop() {
	if(stempty())
	printf("stack is empty");
	else{
		
	peep();
	st.top--;
}
}

void display() {
	int i;
   if (stempty())
      printf("\nStack Is Empty!");
   else {
      for (i = st.top; i >= 0; i--)
         printf("\nBOOK NAME = %s BOOK ID = %d BOOK PRICE = %d",st.s[i].book_name,st.s[i].book_id,st.s[i].book_price);  
   }
}




int main() {
   int item, choice;
   char ans;
   st.top = -1;
 
   printf("\n\tImplementation Of Stack");
  do{

      printf("\n1.Push \n2.Pop \n3.Peep \n4.Display \n5.exit");
      printf("\nEnter Your Choice");
      scanf("%d", &choice);
      switch (choice) {
	case 1:
		push();
			break;
	case 2:
		pop();
			break;
	case 3:
		peep();
			break;
	case 4:
		display();
 			break;
	case 5:
		exit (0);
			break;

	}
}while(1);
}

































