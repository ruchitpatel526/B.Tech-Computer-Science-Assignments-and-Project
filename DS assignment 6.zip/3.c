#include<stdio.h>
#include<conio.h>
#define max 5

void insert();
void del();
void display();
int planes[max];
int front=-1,rear=-1;
int main()
{
     int choice;
     while(1)
     {
             printf("\nPress 1 to Enqueue\n");
             printf("Press 2 to Dequeue\n");
             printf("Press 3 to Display\n");
             printf("Press 4 to Exit\n");
             printf("Enter your choice:");
             scanf("%d",&choice); 
             switch(choice)
             {
                   case 1:
                        insert();
                        break;
                   case 2:
                        del();
                        break;
                   case 3:
                        display();
                        break;
                   case 4:
                        return 0;
                   default:
                           printf("\n Invalid Choice");
                           break;
             }
     }
getch();
}

void insert()
{
        int pl;
        if(front == (rear+1)%max)
        {
                     printf("\n Queue Overflow.\n\n");
                     return;
        }
        if(front==-1)
        {
                     front=0;
                     rear=0;
        }
        else
        {
            rear=(rear+1)%max;
        }
        printf("\n Input the plane for insertion in queue:");
        scanf("%d",&pl);
        planes[rear]=pl;
        printf("Element inserted.");
}

void del()
{
     if(front==-1)
     {
          printf("\n Queue Underflow.\n\n");
          return;
     }
     printf("\n Plane deleted from the Queue is %d \n\n",planes[front]);
     if(front==rear)
     {
                    front=-1;
                    rear=-1;
     } 
     else
     { 
        front=(front+1)%max;
     }
}

void display()
{
     if(front==-1)
     {
                  printf("\n Queue is empty.\n");
                  return;
     }
     printf("\n Planes is: \n");
     int i = front;
     do{
        printf("%d\t",planes[i]);
        i=(i+1)%max;
     }while((i-1) != rear);
}