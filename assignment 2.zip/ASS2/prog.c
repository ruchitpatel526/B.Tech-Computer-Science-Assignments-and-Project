#include<stdio.h>
#include"STRING.h"
void main()
{
int i;
printf("press 1 find lenght of string\n");
scanf("%d",&i);
switch(i)
{
case 1:
lenght();
break;

case 2:
concatenation();
break;

case 3:
rfi();
break;

case 4:
rlo();
break;

case 5:
sub();
break;

case 6:
replace();
break;

case 7:
comparison();
break;

case 8:
casecomparison();
break;

case 9:
rev();
break;

case 10:
uprcase();
break;

case 11:
lwrcase();
break;

case 12:
ttlcase();
break;

case 13:
dupcon();
break;

case 14:
revcon();
break;

case 15:
pdm();
break;

case 16:
vvl();
break;

case 17:
chr();
break;




}
}
