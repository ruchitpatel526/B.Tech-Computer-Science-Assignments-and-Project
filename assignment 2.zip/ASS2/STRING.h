//1
void lenght(void)
{
int i=0;
char a[50];
printf("enter your string\n");
scanf("%s",a);
while(a[i]!='\0')
{
i=i+1;
}
printf("lenght of string is %d\n",i);
}

//2
void concatenation(void)
{
int i,j;
char c[100];
char a[50],b[50];
printf("enter the strings\n");
scanf("%s \n%s",a,b);
for(i=0;a[i]!='\0';i++)
c[i]=a[i];
for(j=i;b[j-i]!='\0';j++)
c[j]=b[j-i];
c[j]='\0';
printf("final string is %s\n",c);
}

//3
void rfi(void)
{
int i=0,j;
char c[100],symbole;
printf("enter your string and symbole\n");
scanf("%s \n%c",c,&symbole);
{for(j=0;c[j]!='\0';j++);
c[j]='\0';
for(i=0;c[i]!='\0';i++)
{char x=c[i];
if(x==symbole)
{printf("your symbol is at index %d from first\n",i);}
}
}}

//4
void rlo(void)
{
int i=0,j,k;
char c[100],symbole;
printf("enter your string and symbole\n");
scanf("%s \n%c",c,&symbole);
{for(j=0;c[j]!='\0';j++);
c[j]='\0';
k=j-1;
for(i=j-1;i>=0;i--)
{char x=c[i];
if(x==symbole)
{printf("your symbol is at index %d from last\n",k-i);}
}
}}

//5
void sub(void)
{
 char b[100],c[100];
 int i,a,k,l,temp=0;
printf("enter the string and substring\n");
scanf("%s \n%s",b,c);

  for(i=0;b[i]!='\0';i++)
   {
    if(b[i]==c[0])
    {
     while(c[l]!='\0'&&b[l+i]!='\0'&&c[l]==b[l+i])
    {
     l++;
     temp=1;
     k=i;
    }
   }
}
   
if(temp==1&&c[l]=='\0')
printf("your index is %d\n",k);
}



//6
void replace(void)
{
 char b[50],c[50];
 int i,j,k,l,n;
 printf("enter the string,substring and position\n");
 scanf("%s \n%s \n%d",b,c,&n);

 for(i=n;c[i-n]!='\0';i++)
 {
 	b[i]=c[i-n];
 }
printf("your updated string is %s\n",b);
}


//7
void comparison(void)
{
	int i,j,k,a=0;
	char s1[50],s2[50]; 
	printf("enter the strings you want to compare\n");
	scanf("%s \n%s",s1,s2);
	for(i=0;s1[i]!='\0';i++);
	for(j=0;s2[j]!='\0';j++);
	if(i!=j)
	printf("strings is not equal\n");
	if(i=j)
	{
	for(k=0;k<i;k++)
	{
	if(s1[k]==s2[k])
	{//printf("%d char is same\n",k+1);
	a+=1;}
	else if(s1[k]!=s2[k])
	printf("%d char is different\n",k+1);
	}
	}
	if(a==k)
	printf("strings are same\n");
	if(a!=k)
	printf("strings are not same\n");
	}


//8
void casecomparison(void)
{
	int i,j,k,l,a=0;
	char s1[50],s2[50]; 
	printf("enter the strings you want to compare\n");
	scanf("%s \n%s",s1,s2);
	
	for(i=0;s1[i]!='\0';i++)
	{
		if(s1[i]>=65&&s1[i]<=90)
		{
	    s1[i]=s1[i]+32;
	    }
	}
	for(i=0;s2[i]!='\0';i++)
	{
		if(s2[i]>=65&&s2[i]<=90)
		{
		s2[i]=s2[i]+32;
        }
	}
	for(i=0;s1[i]!='\0';i++);
	for(j=0;s2[j]!='\0';j++);
	//if(i!=j)
	//printf("strings is not equal\n");
	if(i=j)
	{
	for(k=0;k<i;k++)
	{
	if(s1[k]==s2[k])
	{//printf("%d char is same\n",k+1);
	a+=1;}
	else if(s1[k]!=s2[k])
	printf("%d char is different\n",k+1);
	}
	}
	if(a==k)
	printf("strings are same\n");
	if(a!=k)
	printf("strings are not same\n");	
	}


//9
void rev(void)
{
	char s1[50],s2[50]; 
	printf("enter the string you want to reverse\n");
	scanf("%s",s1);
	printf("\n");
	int n,i;
	for(n=0;s1[n]!='\0';n++);
	for(i=0;i<n;i++)
	{
	s2[n-i-1]=s1[i];}
	
	printf("your reverse string is \n");
	
	
		printf("%s",s2);
	printf("\n");
}

//10
void uprcase(void)
{
	char s1[50]; 
	printf("enter the string you want in upercase\n");
	scanf("%s",s1);
	printf("\n");
	int i,j,k,l;
		for(i=0;s1[i]!='\0';i++)
	{
		if(s1[i]>=97&&s1[i]<=122)
		{
	    s1[i]=s1[i]-32;
	    }
	}
	printf("your string is %s\n",s1);
	
}


//11
void lwrcase(void)
{
	char s1[50],s2[50]; 
	printf("enter the string you want in lowercase\n");
	scanf("%s",s1);
	printf("\n");
	int i,j,k,l;
		for(i=0;s1[i]!='\0';i++)
	{
		if(s1[i]>=65&&s1[i]<=90)
		{
	    s1[i]=s1[i]+32;
	    }
	}
	printf("your string is %s",s1);
	printf("\n");
}
	

//12
void ttlcase(void)
{
	char s1[50]; 
	printf("enter the string you want in titlecase\n");
	scanf("%s",s1);
	printf("\n");
	int i,j,k,l;
	if(s1[0]>=97&&s1[0]<=122)
	    s1[0]=s1[0]-32;
	    
        for(i=1;s1[i]!='\0';i++)
  	{
		 if(s1[i]>=65&&s1[i]<=90)
		{
	    s1[i]=s1[i]+32;
	    }
     	
	}
	printf("your string is %s",s1);
	printf("\n");
}


//13
void dupcon(void)
{
	char s1[50];
	printf("enter your string");
	printf("\n");	
	scanf("%s",s1);
	printf("\n");

	int n,i,j,k,l;
	char s2[50];
	for(n=0;s1[n]!='\0';n++);	
	
	for(i=0;i<n;i++)
	{
		s2[i]=s1[i];
	}
	printf("%s%s",s2,s1);
	printf("\n");
	}


//14
void revcon(void)
{
	char s1[50];
	printf("enter your string");
	printf("\n");	
	scanf("%s",s1);
	printf("\n");

	int n,i,j,k,l;
	char s2[50];
	for(n=0;s1[n]!='\0';n++)
	{	
	}
	for(i=0;i<n;i++)
	{
		s2[i]=s1[n-i-1];
	}
	printf("%s%s",s1,s2);
}




//15
void pdm(void)
{
	char s1[50];
	printf("enter your string");
	printf("\n");	
	scanf("%s",s1);
	printf("\n");

	int n,i,j,c=0;
	for(n=0;s1[n]!='\0';n++);
	j=n/2;	
	for(i=0;i<j;i++)
	{
		if(s1[i]==s1[n-i-1])
		{
			c+=1;
		}
	}
	if(c==j)
	{
		printf("this string is pelindrom\n");
	}
	else
	{
		printf("this string is not pelindrom\n");
	}
}


//16
void vvl(void)
{
	char s1[50];
	printf("enter your string");
	printf("\n");	
	scanf("%s",s1);
	printf("\n");

	int i,j,k,l=0;
	for(i=0;s1[i]!='\0';i++)
	{
		if(s1[i]=='a'||s1[i]=='e'||s1[i]=='i'||s1[i]=='o'||s1[i]=='u'||s1[i]=='A'||s1[i]=='E'||s1[i]=='I'||s1[i]=='O'||s1[i]=='U')
		{
			l++;
		}
	}
	
	printf("\ntotal number of vowel is %d\n",l);
}



void chr(void)
{
	
	char s1[50];
	printf("enter your string");
	printf("\n");
	scanf("%s",s1);
	printf("\n");

	int i,j,k,l=0,n;
	for(n=0;s1[n]!='\0';n++);
	for(i=0;s1[i]!='\0';i++)
	{
		if(s1[i]==' ')
		{
			l++;
		}
	}
	printf("total number of character is %d\n",n-l);
	printf("total number of the words is %d\n",l+1);
}





  
   
     
