#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

struct stack
	{
		int top;
		char a[40];
	}st,temp;

void push(char t3)			
	{
		st.top+=1;
		st.a[st.top]=t3;
	}
void pushtemp(char t3)			
	{
		temp.top+=1;
		temp.a[temp.top]=t3;
	}
void display()
	{
		int x;
		for(x=0;x<=st.top;x++)
		printf("%c",st.a[x]);
		exit(0);
	}
void main()
	{
		st.top = -1;
		temp.top = -1;
		char exp[40],t3;
		int x=0,i=0;
		printf("\nENTER YOUR INFIX EXPRESSION :: ");
		scanf("%s",exp);
		st.top=-1;
		temp.top=-1;
		while(exp[i]!='\0')
		{
			if(exp[i]=='('){
					t3=exp[i];
					pushtemp(t3);
				}
			else if((exp[i]>=65&&exp[i]<=90)||(exp[i]>=97&&exp[i]<=122)||(exp[i]>=48&&exp[i]<=57)){
				t3=exp[i];
				push(t3);
			}
			else if(exp[i]=='+'||exp[i]=='-'){
				if(temp.top==-1||temp.a[temp.top]=='('){
					t3=exp[i];
					pushtemp(t3);
				}
				else{
					while(temp.top != -1 && temp.a[temp.top]!='('){
						t3=temp.a[temp.top];
						push(t3);
						temp.top -= 1;
					}
					t3=exp[i];
					pushtemp(t3);
				}
			}
			else if(exp[i]=='/'||exp[i]=='*'){
				if(temp.top==-1 || temp.a[temp.top]=='(' || temp.a[temp.top]=='+' || temp.a[temp.top]=='-')
				{
					t3=exp[i];
					pushtemp(t3);
				}			
				else
				{
					while(temp.top!=-1 && temp.a[temp.top]!='(' && temp.a[temp.top]!='+' && temp.a[temp.top]!='-'){
						t3=temp.a[temp.top];
						push(t3);
						temp.top-=1;
					}
					t3=exp[i];
					pushtemp(t3);
				}
			}
			else if(exp[i]==')'){
					while(temp.top != -1&&temp.a[temp.top]!='(')	{
							t3=temp.a[temp.top];
							push(t3);
							temp.top-=1;
						}
					temp.top-=1;	
				}
			else if(exp[i]=='^'){
					t3=exp[i];
					pushtemp(t3);
				}
			i++;
			
		}
		while(temp.top!=-1){
			t3=temp.a[temp.top];
			push(t3);
			temp.top-=1;
		}
		display();
	}



