#include <stdio.h>
#include <stdlib.h>
#define SIZE 40

struct stack{
    int a[SIZE];
    int top;
}st;

int isOp(char ch){
    if(ch == '+')
        return 1;
    if(ch == '-')
        return 2;
    if(ch == '*')
        return 3;
    if(ch == '/')
        return 4;
    if(ch == '^')
        return 5;
    return 0;
}
int ans(char *exp)
{
    int op;
    int i=0;
    while(exp[i] != '\0')
    {
        op = isOp(exp[i]);
        if(op)
        {
            switch(op)
            {
                if(st.top <= 0)
                {
                    printf("\nWrong exp.");
                    exit(0);   
                }
                case 1:
                {
                    st.a[st.top-1]+=st.a[st.top];
                    st.top--;
                    break;
                }
                case 2:
                {
                    st.a[st.top-1]-=st.a[st.top];
                    st.top--;
                    break;
                }
                case 3:
                {
                    st.a[st.top-1]*=st.a[st.top];
                    st.top--;
                    break;
                }
                case 4:
                {
                    st.a[st.top-1]/=st.a[st.top];
                    st.top--;
                    break;
                }
                case 5:
                {
                    st.a[st.top-1]^=st.a[st.top];
                    st.top--;
                    break;
                }
            }
        }
        else{
            if(!(exp[i] >= 48 && exp[i] <= 57))
            {
                printf("\nWrong exp");
                exit(0);
            }
            st.a[st.top+1] = exp[i]-48;
            st.top++;
        }
        i++;
    }   
    return st.a[st.top];
}
int main()
{
    char exp[SIZE];
    printf("\nEnter the postfix exp. to evalute :: ");
    scanf("%s",exp);
    printf("%d",ans(exp));
    return 0;
}