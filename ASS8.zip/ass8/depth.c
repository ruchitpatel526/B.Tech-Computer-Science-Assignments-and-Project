#include <stdio.h>
#include <stdlib.h>
#define MAX 65344

struct node{
	int data;
	struct node* lptr;
	struct node* rptr;
};
struct node *head;

int depth(struct node *root){
	int maxim = 0;
	int l_max=0;
	int r_max=0;
	if(root==NULL)
		return -1;
	if(root->lptr!=NULL)
	{
		l_max = depth(root->lptr);
	}
	if(root->rptr!=NULL)
	{
		r_max = depth(root->rptr);
	}
	maxim = (l_max > r_max) ? l_max : r_max;
	return maxim+1;

}

int elements(struct node* root,int ele)
{
	if(root==NULL)
		return ele;
	if(root->lptr!=NULL)
	{
		ele = elements(root->lptr,ele);
	}
	if(root->rptr!=NULL)
	{
		ele = elements(root->rptr,ele);
	}
	return ele+1;
}


struct node* findRoot(int val){
	struct node* trav;
	if(head->lptr == NULL && head->rptr == NULL)
	{
		return head;
	}
	trav=head->lptr;
	while(trav!=NULL)
	{
		if(val < trav->data)
		{
			if(trav->lptr == NULL)
			{
				return trav;
			}
			trav = trav->lptr;
		}
		if(val > trav->data)
		{
			if(trav->rptr == NULL)
			{
				return trav;
			}
			trav = trav->rptr;
		}
		if(val == trav->data)
		{
			return NULL;
		}
	}
	return NULL;
}

struct node* create()
{
	struct node *temp;
	temp = (struct node*)malloc(sizeof(struct node));
	printf("Enter Data to be inserted :: ");
	scanf("%d",&temp->data);
	temp->lptr = NULL;
	temp->rptr = NULL;
	return temp;
}

void insert(){
	struct node *temp,*parent;
	temp = create();
	parent = findRoot(temp->data);
	if(parent == NULL)
	{
		printf("Value Exists\n");
		insert();
		return;
	}
	if(temp->data < parent->data)
	{
		parent->lptr = temp;
	}
	else
	{
		parent->rptr = temp;
	}
}

void delete(struct node *root)
{
	if(root==NULL)
		return;
	if(root->lptr!=NULL)
	{
		delete(root->lptr);
	}
	if(root->rptr!=NULL)
	{
		delete(root->rptr);
	}
	free(root);
	return;
}

int maximum(struct node *root,int max)
{
	if(root==NULL)
	{
		return max;
	}		
	if(root->lptr != NULL)
	{
		max = maximum(root->lptr,max);
	}
	if(root->rptr != NULL)
	{
		max = maximum(root->rptr,max);
	}
	if(max < root->data)
	{
		return root->data;
	}
	return max;
}

int minimum(struct node *root,int min)
{
	if(root==NULL)
	{
		return min;
	}		
	if(root->lptr != NULL)
	{
		min = maximum(root->lptr,min);
	}
	if(root->rptr != NULL)
	{
		min = maximum(root->rptr,min);
	}
	if(min > root->data)
	{
		return root->data;
	}
	return min;
}

void display(struct node* root)
{
	if(root==NULL)
		return;
	printf("%d",root->data);
	if(root->lptr!=NULL)
	{
		printf("{");
		display(root->lptr);
	}
	if(root->rptr!=NULL)
	{
		printf("}");
		display(root->rptr);
	}
}
void main()
{
	int ch=0,num=0,i=0;
	head = (struct node*)malloc(sizeof(struct node));
	head->data = MAX;
	head->lptr = NULL;
	head->rptr = NULL;
	while(1){
		printf("\n1 :: Create Tree");
		printf("\n2 :: Depth");
		printf("\n3 :: Display");
		printf("\n4 :: number of elements");
		printf("\n5 :: delete tree");
		printf("\n6 :: maximum and minimum");
		printf("\n7 :: Exit");
		printf("\nEnter choice :: ");
		scanf("%d",&ch);
		
		switch(ch)
		{
			case 1:
				printf("How many nodes :: ");
				scanf("%d",&num);
				for(i=0;i<num;i++)
				{
					insert();
				}
				break;
			
			case 2:
				printf("\nHeight = %d",depth(head->lptr));
				break;
			case 3:
				display(head->lptr);
				break;
			case 4:
				printf("\nElement No. = %d",elements(head->lptr,0));
				break;
			case 5:
				delete(head->lptr);
				head->lptr = NULL;
				break;
			case 6:
				if(head->lptr == NULL)
				{
					printf("\ntree is null");	
				}
				else
				{
				printf("\nmaximum number is = %d",maximum(head->lptr,head->lptr->data));
				printf("\nminimum number is = %d",minimum(head->lptr,head->lptr->data));
				}
				break;	
			case 7:
				exit(0);
				break;
			default:
				printf("\nWrong Choice");
		}
	}
}
