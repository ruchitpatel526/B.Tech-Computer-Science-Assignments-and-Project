<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
		<?php
			$uname= $pass = "";
			if(isset($_POST['login']))
			{
			$uname = $_POST['uname'];
			$pass = $_POST['password'];
			@mysql_connect("localhost","root","") or die(mysql_error());
			mysql_select_db("user") or die(mysql_error());
			$check = mysql_query("SELECT * FROM info WHERE username = '$uname' AND password = '$pass' ");
			$row=mysql_num_rows($check);
			if($row!=0)
			{
				$result=mysql_fetch_array($check);
				$dbuname=$result['username'];
				$dbpassword=$result['password'];
				if($dbuname==$uname && $dbpassword==$pass)
				{
					session_start();
					$_SESSION['username'] = $uname;
					echo "succesful";
					header("location: http://localhost/rogue/home.php");
				}
				else
				{
					echo "Invalid UserName or Password";
				}
			}
			else
				echo "Invalid username or Password";
			}
			
		?>
		<div>
			<form method="POST" action="login.php" >
				<table>
					<tr>
						<td>UserName:</td>
						<td><input type="text" name="uname" placeholder="UserName"></td>
					</tr>
					<tr>
						<td>Password:</td>
						<td><input type="password" name="password" placeholder="Password"></td>
					</tr>
					<tr>
						<td><input type="submit" name="login" value="Log In" ></td>
					</tr>
				</table>
			</form>
		</div>
		<div>
			<a href="register.php">Create a New Account</a>
		</div>
</body>
</html>