<!DOCTYPE html>
<html>
<head>
	<title>sql_php</title>
</head>
<body>
		<?php
				echo "DataBase Connection";
				mysql_connect("localhost","root","") or die(mysql_error());
				mysql_query("CREATE DATABASE company") or die(mysql_error());
				mysql_select_db("company") or die(mysql_error());
				mysql_query("CREATE TABLE employee (id INT AUTO_INCREMENT,FirstName varchar(20),LastName varchar(20),Phone varchar(10),BirthDate DATE,PRIMARY KEY(id))") or die(mysql_error());
				mysql_query("INSERT INTO employee(FirstName,LastName,Phone,BirthDate,id) VALUES('Sairam','Naragoni','8790361236','1997-07-01',1)");
				mysql_query("INSERT INTO employee(FirstName,LastName,Phone,BirthDate,id) VALUES('Apurva','Tripathi','8999978455','1997-08-23',2)");
				mysql_query("INSERT INTO employee(FirstName,LastName,Phone,BirthDate,id) VALUES('Jay','Bhairaviya','9898989775','1997-10-22',3)");
				mysql_query("INSERT INTO employee(FirstName,LastName,Phone,BirthDate,id) VALUES('Alkesh','Vaghela','9999777788','1997-07-29',4)");
				mysql_query("INSERT INTO employee(FirstName,LastName,Phone,BirthDate,id) VALUES('Aniket','Meena/Lakhwadh','9368565656','1997-10-24',5)");
				$str = mysql_query ("SELECT * FROM employee");
				echo "<table><tr><th>FirstName<th><th>LastName<th><th>Phone<th><th>DOB<th><th>id<th><tr>";
				while($row=mysql_fetch_array($str)){
						echo "<tr><td>".$row["FirstName"]."<td>";
						echo "<td>".$row["LastName"]."<td>";
						echo "<td>".$row["Phone"]."<td>";
						echo "<td>".$row["BirthDate"]."<td>";
						echo "<td>".$row["id"]."<td><tr>";
					}
					echo "</table>";
					echo "<style>table,td,tr{border:2px solid black;border-collapse:collapse; padding:25px;}</style>";
				//mysql_query("DROP TABLE employee") or die(mysql_error());
				mysql_close();
		?>
</body>
</html>