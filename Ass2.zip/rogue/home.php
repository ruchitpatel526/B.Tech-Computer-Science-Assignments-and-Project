<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
		<?php
				if(!isset($_SESSION['username']))
					header("location: http://localhost/rogue/login.php");
		?>
		<p>WELCOME <?php echo $_SESSION['username']; ?> </p>
		<div>
			<a href="logout.php">Log OUT</a>
		</div>
</body>
</html>