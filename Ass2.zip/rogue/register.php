<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<style type="text/css">
		td.error{
			color: green;
		}
	</style>
</head>
<body>
	<?php
		$passerr = $pass1err = $unameerr = $pmatch = "";
		if($_SERVER["REQUEST_METHOD"]=="POST")
		{	
			if(empty($_POST["uname"]))
				$unameerr="UserName is required";
			if(empty($_POST["password"]))
				$passerr="Password is required";
			if(empty($_POST["password1"]))
				$pass1err="Re-enter the password";
			if($_POST["password"]!=$_POST["password1"])
				$pmatch="Passwords Don't Match";
			if($passerr ==  "" && $pass1err=="" && $unameerr=="" && $pmatch=="" )
				{
					$uname=$_POST["uname"];
					$pass=$_POST["password"];
					@mysql_connect("localhost","root","") or die(mysql_error());
					@mysql_query("CREATE DATABASE  if NOT EXISTS user") or die(mysql_error());
					mysql_select_db("user") or die(mysql_error()) ;
					@mysql_query("CREATE TABLE if NOT EXISTS info (id INT AUTO_INCREMENT,username varchar(20),password varchar(20),PRIMARY KEY(id))") or die(mysql_error());
					$exist = mysql_query("SELECT * FROM info WHERE username='$uname'");
					$result=@mysql_fetch_array($exist);
					if($uname==$result['username'])
					{
						die("User with same Username Exists,Try Again with Another UserName");
					}
					else
					{
						session_start();
						mysql_query("INSERT INTO info (username,password) VALUES ('$uname','$pass')");
						$_SESSION['username'] = $uname;
						echo "You have successfully registered";
						header("location: http://localhost/rogue/home.php");
					}		
				}
		}		
	?>
	<div>
		<form method="POST" action="register.php">
			<table>
				<tr>
					<td>Enter Your UserName:</td>
					<td><input type="text" name="uname" placeholder="UserName"></td>
					<td class="error"><?php echo $unameerr; ?></td>
				</tr>
				<tr>
					<td>Choose a Password</td>
					<td><input type="password" name="password" placeholder="password"></td>
					<td class="error"><?php echo $passerr; ?></td>
				</tr>
				<tr>
					<td>ReEnter Password</td>
					<td><input type="password" name="password1" placeholder="Retype password"></td>
					<td class="error"><?php echo $pass1err; ?></td>
					<td class="error"><?php echo $pmatch; ?></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="register" value="Register"></td>
				</tr>
			</table>
		</form>
	</div>
</body>
</html>