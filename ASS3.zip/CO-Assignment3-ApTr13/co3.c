#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
	if(argc!=2)
	{
		printf("arguments are not valid.\n");
		return 1;
	}
	long num,i,n,q=0;
	num=atoi(argv[1]);
	printf("enter 2 or multiple of 2 from which you want to divide your number:");
	scanf("%ld",&n);
	for(i=num;num>0;i--)
	{
		q=q+1;
		num=num-n;
	}
	printf("the division is %ld and the remainder is %ld",q,num);
	return 0;
}
