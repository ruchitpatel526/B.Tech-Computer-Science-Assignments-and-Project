#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
	long num1, num2, div;
	if(argc!=3)
	{
		printf("not valid...\n");
	}
	else
	{
		num1=atoi(argv[1]);
		num2=atoi(argv[2]);
		if(num1>=num2)
			div=num1/num2;
		else
			div=num2/num1;
		printf("division of the two numbers is %ld",div);
	}
	return 0;
}
