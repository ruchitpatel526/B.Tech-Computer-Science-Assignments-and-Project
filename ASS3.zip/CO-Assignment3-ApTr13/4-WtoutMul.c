#include<stdio.h>

int main(int argc, char *argv[])
{
	if(argc==3)
	{	long int a,b,i,c=0;
		printf("a=%d\n",atoi(argv[1]));
		printf("b=%d\n",atoi(argv[2]));

		if(atoi(argv[1])%2!=0||atoi(argv[2])%2!=0)
		{	printf("Inappropriate arguments.\n");
			printf("Arguments should be multiple of 2.\n\n");
		}

		for(i=1;i<=atoi(argv[2]);i++)
			c=c+a;
		printf("Multiplication of a&b=%d\n\n",c);
	}
	else
	{	printf("Inappropriate arguments.\n");
		printf("Retry by giving two long numbers in argument.\n\n");
	}
}
