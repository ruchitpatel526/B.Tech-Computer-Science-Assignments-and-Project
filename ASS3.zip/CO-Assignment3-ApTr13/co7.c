#include<stdio.h>
int main()
{
	float a;
	printf("enter any number:");
	scanf("%f",&a);
	printf("\n%f",a);
	printf("\n%0.2f",a);
	printf("\n%3.4f",a);
	printf("\n%10f",a);
	printf("\n%010f",a);
	printf("\n%-7.2f",a);
}
