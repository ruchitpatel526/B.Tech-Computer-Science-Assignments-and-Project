#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(int argc,char *argv[])
{
   
   double a1,a2;
   double div;
   float b,e,t;
   b=clock();
   if (argc != 3) 
   {
      printf("You have forgot to type numbers.");
      return 0;
   }
	printf("intial time: %f",b);   
   	printf("\nThe div is : ");
	a1=atoi(argv[1]);
	a2=atoi(argv[2]);
	if(a1>=a2)
		div=a1/a2;
	else
		div=a2/a1;
   	printf("%lf \n", div);
	e=clock();
	printf("final time: %f",e);
	t=(e- b)/CLOCKS_PER_SEC;
	printf("\nfirst Execution time is: %f \n ",t);
}

