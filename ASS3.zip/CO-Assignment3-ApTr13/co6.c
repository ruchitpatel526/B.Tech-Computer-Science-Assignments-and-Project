#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(int argc,char *argv[])
{
   
   double a1,a2;
   double mul;
   float b,e,t;
   b=clock();
   if (argc != 3) 
   {
      printf("You have forgot to type numbers.");
   }
	printf("intial time: %f",b);   
   	printf("\nThe multiplication is : ");
	a1=atoi(argv[1]);
	a2=atoi(argv[2]);
	mul=a1*a2;
   	printf("%lf \n", mul);
	e=clock();
	printf("final time: %f",e);
	t=(e- b)/CLOCKS_PER_SEC;
	printf("\nfirst Execution time is: %f \n ",t);
}

