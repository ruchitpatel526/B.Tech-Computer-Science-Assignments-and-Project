#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
	if(argc!=2)
	{
		printf("arguments are not valid.\n");
		return 1;
	}
	long num,i,n,sum=0;
	num=atoi(argv[1]);
	printf("enter the 2 or multiple of 2 from which you want to multiplay your number:");
	scanf("%ld",&n);
	for(i=0;i<n;i++)
	{
		sum=sum+num;
	}
	printf("the multiplication is %ld",sum);
	return 0;
}
