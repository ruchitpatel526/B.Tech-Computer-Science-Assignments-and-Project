#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
{
	long num1, num2, mul;
	if(argc!=3)
	{
		printf("not valid arguments\n");
		return 1;
	}
	else
	{
		num1=atoi(argv[1]);
		num2=atoi(argv[2]);
		mul=num1*num2;
		printf("multiplication of the two numbers is %ld",mul);
	}
	return 0;
}
