#include<stdio.h>

int main(int argc, char *argv[])
{
	if(argc==3)
	{	printf("a=%d\n",atoi(argv[1]));
		printf("b=%d\n",atoi(argv[2]));
		printf("Division of a&b=%d\n\n",atoi(argv[1])/atoi(argv[2]));
	}
	else
	{	printf("Inappropriate arguments.\n");
		printf("Retry by giving two long numbers in argument.\n\n");
	}
}
