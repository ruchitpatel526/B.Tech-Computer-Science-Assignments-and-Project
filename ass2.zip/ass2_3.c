#include <stdio.h>
void main()
{
	float num;
	printf("Enter the number = ");
	scanf("%f",&num); 
	printf("\n1(%%i)   : %i",(int)num); 
	printf("\n2(%%021d)  : %021d",(int)num);  
	printf("\n3(%%ld)  : %ld",(int)num); 
	printf("\n4(%%e)   : %e",num);
	printf("\n5(%%c)   : %c",num);
	printf("\n6(%%d)   : %d",(int)num);
	printf("\n7(%%f)   : %f",num);
	printf("\n8(%%.21f) : %.21f",num);
	 
}
