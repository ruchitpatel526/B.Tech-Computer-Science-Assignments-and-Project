#include <stdio.h>
void complement(int *bin,int *ans)
{
	int i=0;
	for(i=0;i<10;i++)
	{
		ans[i]=!bin[i];
	}
}
void reset(int* bin)
{
	int i;
	for(i=0;i<10;i++)
	{
		bin[i] = 0;
	}
}
void addition(int* bin1,int* bin2,int* ans)
{
	int i=0,raise=0,sum=0;
	for(i=9;i>=0;i--)
	{
		sum=bin1[i]+bin2[i]+raise;
		if(sum%2==0)
			ans[i]=0;
		else
			ans[i]=1;
		if(sum>=2)
			raise=1;
		else
			raise=0;
	}
	if(raise==1)
	{
		printf("\nOut of bound");
	}	
}
void convert(int num,int* bin)
{
	int i=0,temp1[10],add1[10],temp2[10];
	reset(temp1);
	reset(add1);
	reset(temp2);
	add1[10]=1;
	if(num>=0)
	{
		for(i=9;num!=0;i--)
		{
			bin[i] = num%2;
			num/=2;
		}
	}
	else
	{
		num=-num;
		for(i=9;num!=0;i--)
		{
			temp1[i] = num%2;
			num/=2;
		}
		complement(temp1,temp2);
		addition(temp2,add1,bin);
	}
}
void display(int* bin)
{
	int i=0;
	printf("\nADDITION OF THIS BINARY NUMBERS = ");
	for(i=0;i<10;i++)
	{
		printf("%d",bin[i]);
	}
}
void main()
{
	int num1,num2,bin1[10],bin2[10],ans[10];	
	printf("ENTER NUM1 = ");
	scanf("%d",&num1);
	printf("\nENTER NUM2 = ");
	scanf("%d",&num2);
	reset(bin1);
	reset(bin2);
	reset(ans);
	convert(num1,bin1);
	convert(num2,bin2);
	addition(bin1,bin2,ans);
	display(ans);
}
