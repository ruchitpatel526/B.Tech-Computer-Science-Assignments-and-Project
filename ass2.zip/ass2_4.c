#include<stdio.h>

void convert(unsigned int num,unsigned int* bin)
{ 
	int i=0;
	for(i=9;num!=0;i--)
	{
		bin[i] = num%2;
		num/=2;
	}
}

void reset(unsigned int* bin)
{
	int i;
	for(i=0;i<10;i++)
	{
		bin[i]=0;
	}
}

void addition(unsigned int* bin1,unsigned int* bin2,unsigned int* ans)
{
	int i=0,sum=0,raise=0;
	for(i=9;i>=0;i--)
	{
		sum=bin1[i]+bin2[i]+raise;
		if(sum%2==0)
		ans[i]=0;
		else
		ans[i]=1;
		if(sum==2)
		raise=1;
		else
		raise=0;
	}
	
		
}


void display(unsigned int* bin)
{
	int i=0;
	printf("\nADDITION OF THESE BINARY NUMBERS = ");
	for(i=0;i<10;i++)
	{
		printf("%u",bin[i]);
		
	}
}

void main()
{
	unsigned int num1,num2,bin1[10],bin2[10],ans[10];
	printf("ENTER NUM1 = ");
	scanf("%u",&num1);
	printf("ENTER NUM2 = ");
	scanf("%u",&num2);
	reset(bin1);
	reset(bin2);
	reset(ans);
	convert(num1,bin1);
	convert(num2,bin2);
	addition(bin1,bin2,ans);
	display(ans);
}
