#include<stdio.h>

int len(unsigned int num)
{
	int i=0;
	while(num!=0)
	{
		num/=2;
		i++;
	}
	return i;
}

void and(unsigned *bin1,unsigned *bin2,unsigned *ans)
{
  int i=0;
  for(i=0;i<10;i++)
       {
           ans[i]=bin1[i]*bin2[i]; 
        }
}


void or(unsigned *bin1,unsigned *bin2,unsigned *ans)
{
  int i=0;
  for(i=0;i<10;i++)
       {
          if(bin1[i]==0&&bin2[i]==0)
             { 
             ans[i]=0;
		}
          else
            {
             ans[i]=1;
             }

	    }
}
void xor(unsigned *bin1,unsigned *bin2,unsigned *ans)
{  int i=0;
        for(i=0;i<10;i++)
        {
          if(bin1[i]==bin2[i])
          { 
             ans[i]=0;
		}
          else
            {
             ans[i]=1;
             }
        }
}

void xnor(unsigned *bin1,unsigned *bin2,unsigned *ans)
{  
 int i=0;
        for(i=0;i<10;i++)
        {
          if(bin1[i]==bin2[i])
          { 
             ans[i]=1;
		}
          else
            {
             ans[i]=0;
             }
}
}
void complement(unsigned int *bin,unsigned int *ans,int len)
{
	int i=0;
	for(i=10-len;i<10;i++)
	{
		ans[i]=!bin[i];
	}
}
void reset(unsigned int* bin)
{
	int i;
	for(i=0;i<10;i++)
	{
		bin[i] = 0;
	}
}

void display(unsigned int* bin)
{
	int i=0;
	printf("\nBinary num is = ");
	for(i=0;i<10;i++)
	{
		printf("%u",bin[i]);
	}
}




 
void main()
{
   unsigned int num1=0,num2=0,bin1[10],bin2[10],ans[10];
     int i,j,temp=0,len1=0,len2=0;
	reset(bin1);
	reset(bin2);
	reset(ans);
	printf("\nEnter the num1 = ");
	scanf("%u",&num1);
	printf("\nEnter the num2 = ");
	scanf("%u",&num2);
	
	len1=len(num1);
	len2=len(num2);
	temp=len1>len2?len1:len2;

 for(i=0;i<10;i++)
{
     bin1[i]=0;
}

     for(j=0;j<10;j++);
{
     bin2[j]=0;
}

while(num1!=0&&num2!=0)
{

for(i=9;i>=0;i--)
{
 bin1[i]=num1%2;
 num1=num1/2;
}

for(j=9;j>=0;j--)
{
 bin2[j]=num2%2;
 num2=num2/2;
}

} 

for(i=0;i<10;i++)
{	
  printf("%u",bin1[i]);

}
printf("\n");
for(j=0;j<10;j++)
{
printf("%u",bin2[j]);
}
    printf("\n");
    printf("\nBIT OPERATIONS: ");
    printf("\n");
    and(bin1,bin2,ans);
	printf("\nADD = ");
	display(ans);

	or(bin1,bin2,ans);
	printf("\nOR = ");
	display(ans);

	
	xor(bin1,bin2,ans);
	printf("\nXOR = ");
	display(ans);

	xnor(bin1,bin2,ans);
	printf("\nXNOR = ");
	display(ans);
	
	printf("\ncomplement NUM1 = ");
	complement(bin1,ans,temp);
	display(ans);

	printf("\ncomplement of NUM2 = ");
	complement(bin2,ans,temp);
	display(ans);	
}






