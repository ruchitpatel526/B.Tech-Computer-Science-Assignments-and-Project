x = linspace(-pi,2*pi);

x1 = -pi+0.01:0.01:-0.01; 
x2 = 0.01:0.01:pi-0.01;

y1 = sin(x);
y2 = cos(x);
y3 = tan(x);
y4 = cot(x);
y5 = sec(x);
y6 = csc(x1);

subplot(3,2,1);
plot(x,y1),title('Subplot 1: sin(x)')

subplot(3,2,2);
plot(x,y2),title('Subplot 2: cos(x)')

subplot(3,2,3);
plot(x,y3),title('Subplot 3: tan(x)')

subplot(3,2,4);
plot(x1,cot(x1),x2,cot(x2)), grid on,title('Subplot 4: cot(x)')

subplot(3,2,5);
plot(x,y5),title('Subplot 5: sec(x)')

subplot(3,2,6);
plot(x1,csc(x1),x2,csc(x2)),title('Subplot 6: cosec(x)')
