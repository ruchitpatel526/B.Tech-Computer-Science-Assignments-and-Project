x=linspace(0,1);
y=3*(x.^4)+2*(x.^3)+7*(x.^2)+2*(x)+9;
plot(x,y)