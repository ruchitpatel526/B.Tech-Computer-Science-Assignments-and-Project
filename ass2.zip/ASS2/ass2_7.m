x=[5.3,27.6,5.7,2.0,9.2,37.7,3.7,9.0];
label = {'EUL','PES','EFA','EDD','ELDR','FPP','UEN','OTHER'};
pie(x,label);
