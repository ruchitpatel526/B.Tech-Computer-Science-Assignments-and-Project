x = 0:0.1:2*pi;
y1=sin(x);
y2=cos(x);
subplot(2,1,1);
plot(x,y1,'--gs'),title('Subplot 1: sin(x)')

subplot(2,1,2);
plot(x,y2,'--ro'),title('Subplot 2: cos(x)')
