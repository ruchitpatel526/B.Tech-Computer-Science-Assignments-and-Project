t=datetime(2017,1,18)+calweeks(0:9);
y=rand(1,10);
plot(t,y);