#include <stdio.h>
void main()
{
	unsigned num;
	printf("Enter the number = ");
	scanf("%u",&num);
	printf("\n1(%%o) : %o",num); 
  	printf("\n2(%%c) : %c",num);
    printf("\n3(%%21u) : %21u",num);
	printf("\n4(%%x) : %x",num);
	printf("\n5(%%u) : %u",num);
}
